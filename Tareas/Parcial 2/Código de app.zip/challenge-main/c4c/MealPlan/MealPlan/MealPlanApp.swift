//
//  MealPlanApp.swift
//  MealPlan
//
//  Created by Alumno on 08/10/25.
//

import SwiftUI

@main
struct MealPlanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
